package sistemaregistroproyectoslaboratorio;

public enum EstadoActual {

    EN_DESARROLLO,
    ENTRENANDO_MODELO,
    FINALIZADO,

}
