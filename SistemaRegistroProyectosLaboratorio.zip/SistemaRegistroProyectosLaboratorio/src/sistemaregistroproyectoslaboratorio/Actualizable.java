package sistemaregistroproyectoslaboratorio;

public interface Actualizable {

    String actualizarResultados();

}
