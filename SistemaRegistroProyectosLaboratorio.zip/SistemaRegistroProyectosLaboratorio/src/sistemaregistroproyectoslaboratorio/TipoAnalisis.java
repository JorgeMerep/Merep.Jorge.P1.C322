
package sistemaregistroproyectoslaboratorio;


public enum TipoAnalisis {
    
    DESCRIPTIVO,
    INFERENCIAL,
    PREDICTIVO,
    
}
